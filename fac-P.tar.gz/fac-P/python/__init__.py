"""this defines all modules in the fac package.
"""
__all__ = ['fac', 'crm', 'util', 'config', 'const', 'table', 'atom', 'spm']

